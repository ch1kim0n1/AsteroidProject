Version 1
This version is functionally complete but has not been refactored for levels. 

Version 2
This version has been refactored for levels and other improvements.

Version 3
This version was refactored to include multiple game levels, start, win, lose levels. 
A state machine to handle level transitions. 
Refactoring of GameObjects to simplify design. 

Version 4
Refactored GameObject to inherit from Sprite. 

Version 5
Game restart and sample power up added. 
